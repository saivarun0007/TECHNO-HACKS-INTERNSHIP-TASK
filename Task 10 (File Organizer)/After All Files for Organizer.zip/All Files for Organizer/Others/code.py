a = "Hello World"
for _ in range(5):
    print(a)
