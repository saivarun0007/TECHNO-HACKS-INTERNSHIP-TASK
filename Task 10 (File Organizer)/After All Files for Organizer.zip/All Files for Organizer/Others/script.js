document.addEventListener("DOMContentLoaded", () => {
  const mp = document.getElementById("mp");

  mp.addEventListener("click", () => {
    alert("You clicked on Madhya Pradesh (MP)!");
  });
});
